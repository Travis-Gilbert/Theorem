# egglog: The Next-Generation Equality Saturation Engine

<a href="https://egraphs-good.github.io/egglog/">
    <img alt="Web Demo" src="https://img.shields.io/badge/-web demo-blue"></a>
<a href="https://egraphs-good.github.io/egglog/docs/egglog">
    <img alt="Main Branch Documentation" src="https://img.shields.io/badge/docs-main-blue"></a>
<a href="https://codspeed.io/egraphs-good/egglog">
    <img src="https://img.shields.io/endpoint?url=https://codspeed.io/badge.json" alt="CodSpeed Badge"/></a>
<a href="https://egraphs.zulipchat.com/#narrow/stream/375765-egglog">
    <img src="https://img.shields.io/badge/zulip-join%20chat-blue" alt="Zulip Chat"/></a>
<a href="https://codecov.io/gh/egraphs-good/egglog" >
    <img src="https://codecov.io/gh/egraphs-good/egglog/graph/badge.svg?token=7FWFBSKLQE"/></a>

This is the repo for the core of the `egglog` engine, which combines the power of equality saturation and Datalog.

For getting started, try out the [egglog tutorial](https://egraphs-good.github.io/egglog-tutorial)!

You can also [run egglog in your web browser](https://egraphs-good.github.io/egglog/) or check out [the documentation](https://egraphs-good.github.io/egglog/docs/egglog).

For a "battery-included" experience, we recommend [egglog-experimental](https://github.com/egraphs-good/egglog-experimental). It provides more features through additional `egglog` plugins.

If you want to cite `egglog`, please use [this citation](./CITATION.bib).

---

The following instructions are for using/developing the core directly.

## Prerequisites & compilation

Install [Cargo](https://doc.rust-lang.org/cargo/getting-started/installation.html).

```
git clone git@github.com:egraphs-good/egglog.git
cargo install --path=egglog
```

## Usage

The core can be used in REPL mode with:

```
cargo run --release
```

The standard mode processes an input file:

```
cargo run --release [-f fact-directory] [--to-dot] [--to-svg] [-j --threads <THREADS>] <files.egg>
```

* The `--to-dot` command will save a graphviz dot file at the end of the program, replacing the `.egg` extension with `.dot`.
* The `--to-svg`, which requires [Graphviz to be installed](https://graphviz.org/download/), will save a graphviz svg file at the end of the program, replacing the `.egg` extension with `.svg`.
* Set `RUST_LOG=INFO` to see more logging messages, as we use [env-logger](https://docs.rs/env_logger/latest/env_logger/) defaulting to `warn`.
* The `-j` option specifies the number of threads to use for parallel execution. The default value is `1`, which runs everything in a single thread. Passing `0` will use the maximum inferred parallelism available on the current system.

One can also use `egglog` as a Rust library by adding the following to your `Cargo.toml`:

```
[dependencies]
egglog = "2.0.0"
```

See also the [Python binding](https://github.com/egraphs-good/egglog-python) for using `egglog` in Python.

Egglog can also be compiled to WebAssembly, see [./wasm-example](./wasm-example) for more information.

## Development

To view documentation in a browser, run `cargo doc --open`.

Run `cargo test` to run the core `egglog` tests.

### Git size budget

PRs run a Git size budget check to catch accidentally committed generated data
or other large files. The check measures compressed Git objects reachable from
the PR merge commit but not from the base commit, so it also catches files that
were added in an earlier PR commit and deleted before the final diff.

To run the same check locally, compare the base ref with the ref you want to
measure:

```bash
python3 scripts/git-size-budget.py upstream/main HEAD
```

To try different thresholds locally, set `SOFT_LIMIT_BYTES` and
`HARD_LIMIT_BYTES`.

## Community extensions

The community has maintained egglog extensions for IDEs. However, they are outdated at the time of writing.

* [@hatoo](https://github.com/hatoo) maintains an [egglog-language extension](https://marketplace.visualstudio.com/items?itemName=hatookov.egglog-language) in VS Code (just search for "egglog" in VS Code). (Outdated)
* [@segeljakt](https://github.com/segeljakt) maintains a [Neovim plugin](https://github.com/segeljakt/tree-sitter-egg) for egglog using tree-sitter. (Outdated)

## Parallelism

egglog has support to run programs in parallel
via the `-j` flag. This support is relatively new and most users just run
egglog single-threaded; the codspeed benchmarks only evaluate single-threaded
performance. However, please take care not to pessimize parallel performance
where possible (e.g. by adding coarse-grained locks).

We use rayon's global thread pool for parallelism, and the number of threads used
is set to `1` by default when egglog's CLI is run. If you use egglog as a library,
you can control the level of parallelism by setting rayon's `num_threads`.

## Benchmarks

All PRs use [`codspeed`](https://codspeed.io/) to evaluate the performance of a
change against a suite of micro-benchmarks. You should see a "performance
report" from codspeed a few minutes after posting a PR for review. Generally
speaking, PRs should only improve performance or leave it unchanged, though
exceptions are possible when warranted.

To debug performance issues, we recommend looking at the codspeed profiles, or
running your own using
[samply](https://github.com/mstange/samply),
[flamegraph-rs](https://github.com/flamegraph-rs/flamegraph),
[cargo-instruments](https://github.com/cmyr/cargo-instruments) (on MacOS) or
`perf` (on Linux). All codspeed benchmarks correspond to named `.egg` files,
usually in the `tests/` directory. For example, to debug an issue with
`extract-vec-bench`, you can run the following commands:

```bash
# install samply
cargo install --locked samply
# build a profile build which includes debug symbols
cargo build --profile profiling
# run the egglog file and profile
samply record ./target/profiling/egglog tests/extract-vec-bench.egg
# [optional] run the egglog file without logging or printing messages, which can help reduce the stdout
# when you are profiling extracting a large expression
env RUST_LOG=error samply record ./target/profiling/egglog --no-messages tests/extract-vec-bench.egg
```

### CodSpeed

We run all of our "examples" [as benchmarks in CodSpeed](https://codspeed.io/egraphs-good/egglog).
These are in CI for every commit in main and for all PRs. It will run the
examples with extra instrumentation added so that it can capture a single trace
of the CPU interactions
([src](https://docs.codspeed.io/features/understanding-the-metrics/)):

> CodSpeed instruments your benchmarks to measure the performance of your code.
> A benchmark will be run only once and the CPU behavior will be simulated.
> This ensures that the measurement is as accurate as possible, taking into
> account not only the instructions executed but also the cache and memory
> access patterns. The simulation gives us an equivalent of the CPU cycles that
> includes cache and memory access.

Since many of the shorter running benchmarks have unstable timings due to non
deterministic performance ([like in the memory
allocator](https://github.com/oxc-project/backlog/issues/89)), we
["ignore"](https://docs.codspeed.io/features/ignoring-benchmarks/) them in
CodSpeed. That way, we still capture their performance, but their timings don't
show up in our reports by default.

We use 50 ms as our cutoff currently, any benchmarks shorter than that are
ignored. This number was selected to try to ignore any benchmarks with have
changes > 1% when they haven't been modified. Note that all the ignoring is
done manually, so if you add another example that's short, an admin on the
CodSpeed project will need to manually ignore it.


## Code Coverage

To generate code coverage reports locally, first install `cargo-llvm-cov`:

```bash
cargo install cargo-llvm-cov
```

Then run:

```bash
make coverage
```

This will generate a coverage report using `nextest` and output it to `lcov.info`. The coverage report is automatically generated and uploaded to [Codecov](https://codecov.io/) in CI for all pull requests and commits to main.
To visualize coverage in VS Code, we recommend using the [Coverage Gutters](https://marketplace.visualstudio.com/items?itemName=ryanluker.vscode-coverage-gutters) extension. After running `make coverage`, click "Watch" in the status bar to see coverage highlighted in your editor.



## Contributing

We are open to new contributors helping with egglog!

A group of core egglog developers are responsible for final decisions on what code will be accepted.

We organize our issues into three stages:

1. [`status:needs discussion`](https://github.com/egraphs-good/egglog/issues?q=state%3Aopen%20label%3A%22status%3Aneeds%20discussion%22): More work refining this should happen on or offline, before its ready to be considered.
2. [`status: needs decision`](https://github.com/egraphs-good/egglog/issues?q=state%3Aopen%20label%3A%22status%3Aneeds%20decision%22): There is a concrete proposal here which needs to be considered by the core developers.
3. [`status: ready for work`](https://github.com/egraphs-good/egglog/issues?q=state%3Aopen%20label%3A%22status%3Aready%20for%20work%22): This is ready to be implemented and a PR to address it would be supported.

So if you are looking to find an issue to solve, looking for one that is `status: ready for work` will be more likely to result in a PR that could be accepted. We also try to maintain a set of [`good first issue`](https://github.com/egraphs-good/egglog/issues?q=state%3Aopen%20label%3A%22good%20first%20issue%22)s which may be easier to approach.

The core developers will regularly review [all open un-triaged issues](https://github.com/egraphs-good/egglog/issues?q=state%3Aopen%20no%3Alabel) to categorize them.

So if you are unsure if a feature is desired, feel free to open an issue on it first to get feedback before spending time implementing it. 
